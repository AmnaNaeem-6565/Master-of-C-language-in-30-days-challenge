#include<stdio.h>
int main()
{
	printf("|H|\t|H|  |E||E||E||E| |L|\t  |L|\t|O||O||O||O||O|\n");
	printf("|H|\t|H|  |E|          |L|\t  |L|\t|O|         |O|\n");
	printf("|H|\t|H|  |E|          |L|\t  |L|\t|O|         |O|\n");
	printf("|H|\t|H|  |E|          |L|\t  |L|\t|O|         |O|\n");
	printf("|H||H||H||H| |E||E||E|\t  |L|\t  |L|\t|O|         |O|\n");
	printf("|H|\t|H|  |E|          |L|\t  |L|\t|O|         |O|\n");
	printf("|H|\t|H|  |E|          |L|\t  |L|\t|O|         |O|\n");
	printf("|H|\t|H|  |E|          |L|\t  |L|\t|O|         |O|\n");
	printf("|H|\t|H|  |E||E||E||E| |L||L||L|\t|L||L||L||L||O||O||O||O||O|");				
	
	return 0;
	
} 