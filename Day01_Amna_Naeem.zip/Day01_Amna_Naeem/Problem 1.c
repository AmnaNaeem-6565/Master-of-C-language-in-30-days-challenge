#include<stdio.h>
int main()
{
	printf("My Name is [Amna Naeem]");  // printf function prints my name on console screen
	return 0;
	
		}
