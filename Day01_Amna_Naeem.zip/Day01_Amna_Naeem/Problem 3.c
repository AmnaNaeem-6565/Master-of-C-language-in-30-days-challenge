#include<stdio.h>
int main()
{
	printf("___________\n");
	printf("|\n");
	printf("___________\n");
	printf("|\n");
	printf("___________\n");
	return 0;
}