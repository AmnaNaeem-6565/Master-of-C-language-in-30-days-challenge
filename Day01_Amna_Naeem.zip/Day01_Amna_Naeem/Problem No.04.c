#include<stdio.h>
int main()
{
	printf("_______ \t\t\t\t______\n");
	printf("|     | >>---------------------------<< |    |\n");
	printf("_______ \t\t\t\        ______\n");
	printf("\n");
	printf("|------ > \t\t\t    < -------|\n");
	printf("|--------------- > \t    < ----------------\n");
	printf("|------- > \t\t\t     < ------|");
	return 0;
	
}