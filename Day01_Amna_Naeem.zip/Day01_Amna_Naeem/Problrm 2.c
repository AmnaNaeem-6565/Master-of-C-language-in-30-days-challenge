#include<stdio.h>
int main()
{
	printf("This is Master in \"C Language\" 30 days course.\n"); // \n is used for printing the upcoming text on the next line
	printf("This course is organized by TECH INVOLVERS.");
	return 0;
}