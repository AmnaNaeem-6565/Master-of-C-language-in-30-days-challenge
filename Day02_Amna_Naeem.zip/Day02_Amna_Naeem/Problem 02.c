// A program to calculate the sum and average of five integers
#include<stdio.h>
int main()
{
	int a , b , c , d , e;
	float sum , average;
	printf("Enter five numbers: ");
	// we have to take the input in a single line
	scanf("%d %d %d %d %d %d",&a, &b, &c, &d, &e);
	sum= (a+b+c+d+e);
	average=(a+b+c+d+e)/5;
	printf("Sum:%.2f\n",sum);
	printf("Average:%.2f",average);
	return 0;cs
	
	
	
}