// Program that compares two numbers and check whether the two numbers are same or not
#include<stdio.h>
int main()
{
	int number1;
	float number2;
	printf("First number: ");
	scanf("%d",&number1);
	printf("Second number: ");
	scanf("%f",&number2);
	if(number1==number2)
	{
		printf("1");
	}
	else
	{
		printf("0");
	}
	return 0;
}