// A program that takes two numbers and displays their Bitwise AND , OR AND XOR
#include<stdio.h>
int main()
{
	int a , b;
	printf("Enter two numbers: ");
	scanf("%d %d", &a, &b);
	// Bitwise AND
	printf("%d&%d= %d\n",a , b ,a&b);
	// Bitwise OR
	printf("%d|%d= %d\n",a ,b, a|b);
	// Bitwise XOR
	printf("%d^%d= %d\n",a ,b ,a^b);
	// Right Shhift
	printf("%d>>2= %d\n", a , b>>2);
	// Left Shift
	printf("%d<<2= %d\n", a, b<<2);
	return 0;
	
}