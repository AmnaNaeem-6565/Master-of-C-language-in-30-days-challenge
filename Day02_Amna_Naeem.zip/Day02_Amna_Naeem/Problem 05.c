// A program takes the user's age and determine whether the user is eligible for casting vote or note
#include<stdio.h>
int main()
{
	int age;
	printf("Age: ");
	scanf("%d",&age);
	if(age>=18)
	{
		printf("Bravo!You are eligible for vote");
	}
	else
	{
		printf("Sorry,you are not eligible for vote");
	}
	return 0;
}