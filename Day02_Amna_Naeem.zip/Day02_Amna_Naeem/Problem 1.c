// A program to calculate the area of a rectangle
#include<stdio.h>
int main()
{
	int length , width , area;
	printf("Enter the length of rectangle= ");
	scanf("%d",&length);
	printf("Enter the width of rectangle= ");
	scanf("%d",&width);
	area= length*width ;
	// Area of Rectangle= lenghth*width
	printf("Area of the rectangle= %d",area);
	return 0;
}