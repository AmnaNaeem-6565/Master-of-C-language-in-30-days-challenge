// A program to test whether the input sides form a triangle or not
#include<stdio.h>
int main()
{
	int a , b ,c ;
	printf("Enter three angles of a triangle: ");
	scanf("%d %d %d", &a , &b ,&c);
	if(a+b+c==180)
	{
		printf("Yes, such triangle is possible");
	}
	else
	{
		printf("Sorry,such triangle cannot exist");
	}
	return 0;
}