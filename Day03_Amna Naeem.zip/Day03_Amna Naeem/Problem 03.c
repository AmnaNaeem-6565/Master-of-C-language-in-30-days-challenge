// Program takes two random numbers and compute their sum and checks whether the sum is even or odd
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main()
{
	srand(time(NULL));
	int a , b ;
	a = rand() % 90 + 10;
	b = rand() % a;
	printf("Two random numbers: %d %d\n",a , b);
	if((a+b)%2==0)
	{
		printf("Their sum is even");
	}
	else
	{
		printf("Their sum is odd");
	}
	
return 0;	
	
	
}

