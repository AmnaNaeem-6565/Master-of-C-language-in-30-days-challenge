#include<stdio.h> // A program that checks whether a given number is even or odd using Bitwise operator
int main()
{
	int a ;
	printf("Enter the number: ");
	scanf("%d",&a);
	if(a & 1)
	{
		printf("%d is an odd number",a);
	}
	else
	{
		printf("%d is an even number",a);
	}
	return 0;
}