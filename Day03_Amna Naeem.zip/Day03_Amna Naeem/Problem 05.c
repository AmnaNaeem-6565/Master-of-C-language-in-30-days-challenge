// A program that calculates the electricity bill depending upon the consumer type
#include<stdio.h>
int main()
{
	char ch;
	int units ;
	float electricity_cost , total_bill , GST;
	printf("Select the Consumer type:\n");
	printf("C for commercial\n");
	printf("H for home\n");
	printf("Enter Consumer type: ");
	scanf("%c",ch);
	if(ch=='H')
	{
	printf("Enter number of units consumed: ");
	scanf("%d",&units);
	         if(units==100)	
	         {
	         	electricity_cost=units*11;
			 }
			    else if(units<=200)
			    {
			    	electricity_cost= 100*11 + (units-100) * 15;
				}
				    else
			             	{
			             		electricity_cost= 100*11 + 100*15 + (units-200)*20;
					
			                 	}
  GST = electricity_cost*0.1;
  total_bill = electricity_cost + 700 + GST;
  printf("Electricity cost: %f\n",electricity_cost);
  printf("GST: %f\n", GST);
  printf("Net Electricity Bill: %frupees",total_bill);
	}
else
{
	printf("Enter number of units consumed: ");
	scanf("%d",&units);
	if(units==100)
	{
		electricity_cost=units*15;	
	}
	else if(units<=200)
	{
		electricity_cost= 100*15 + (units-100) * 22;
	}
	else
	{
	electricity_cost= 100*15 + 100*22 + (units-200)*30;	
	}
	GST = 0.15*electricity_cost ;
	total_bill= electricity_cost + 1100 + GST ;
	printf("Electricity Cost: %f\n",electricity_cost);
	printf("GST:%f\n", GST);
	printf("Net Electricity bill:%frupees",total_bill);
	}
	return 0;	
}

