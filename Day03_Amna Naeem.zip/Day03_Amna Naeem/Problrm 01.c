#include<stdio.h>
int main()
{
	int a , b, c ;
	printf("Enter three numbers: ");
	scanf("%d %d %d",&a , &b , &c);
	if(a==b && b==c)
	{
		printf("All are equal");
	}
	else
	{
		if(a<b && a<c)
		{
			printf("Smallest number: %d\n",a);
		if(b<c)
		{
			printf("Largest number: %d\n",c);
		}
		else
		{
			printf("Largest number: %d\n",b);
		}
	}
		else if(b<a && b<c)
		{
		printf("Smallest number: %d\n",b);
		if(a<c)
		{
			printf("Largest number: %d\n",c);
		}
		else
		{
			printf("Largest number: %d\n",a);
		}
	}
		else
		{
			printf("Smallest number: %d\n",c);
			if(a<b)
			{
				printf("Largest number: %d\n",b);
			}
			else
			{
				printf("Largest number: %d\n",a);
			}
		}
	}
	      
			   
			   
		
			   
		   
		   return 0;
}