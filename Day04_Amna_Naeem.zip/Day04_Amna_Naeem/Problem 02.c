// A program that calculates the factorial of a number entered by a user
#include<stdio.h> 
int main()
{
	int a , factorial;
	factorial = 1 ;
	printf("Number: ");
	scanf("%d",&a);
	for(int i=1; i<=a; i++)
	{
		factorial = factorial*i ;
	}
		printf("Factorial: %d",factorial);
	return 0;
	
}