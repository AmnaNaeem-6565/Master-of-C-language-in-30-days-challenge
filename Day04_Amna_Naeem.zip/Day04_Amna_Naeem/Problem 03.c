// A program that swaps two variables enterd by a user using Bitwise operators
#include<stdio.h>
int main()
{
	int a , b ;
	printf("Enter Number 1: ");
	scanf("%d",&a);
	printf("Enter Number 2: ");
	scanf("%d",&b);
	// swaps the values of variables using Bitwise OR
	a = a^b ;
	b = a^b ;
	a = a^b ;
	printf("Number 1: %d\n",a);
	printf("Number 2: %d\n",b);
	return 0;
}