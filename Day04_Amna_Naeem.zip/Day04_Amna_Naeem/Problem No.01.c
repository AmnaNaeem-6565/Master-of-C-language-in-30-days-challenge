// A program that takes number from the user and displays the sum of numbers up to number
#include<stdio.h>
int main()
{
	int a , sum;
	sum = 0 ;
	printf("Enter number: ");
	scanf("%d",&a);
	// for loop add the current number to the sum variable in each iteration
	for(int i=1 ; i<=a ; i++)
	{
		sum= sum + i;
		
	}
	printf("Sum: %d",sum);
	return 0;
}