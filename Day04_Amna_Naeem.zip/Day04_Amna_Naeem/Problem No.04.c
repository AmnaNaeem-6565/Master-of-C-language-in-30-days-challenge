// A program that generates a random number between 10 and 20 and asks user to guess the correct number
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main()
{
	int a , guess ;
	srand(time(NULL));
	// Generates a random number between 10 and 20
	a = rand() % 11 + 10 ;
	printf("Guess the number(10-20): ");
	// 1 means true so the loop executes after testing the condition
	while(1)
	{
		scanf("%d",guess);
		if(guess<a)
		{
			printf("Too Low!Try again");
		}
		else if(guess>a)
		{
			printf("Too high!Try again");
		}
		else
		{
			printf("Bravo! you guessed the correct number");
		}
		// break causes to exit from loop body
		break ;
		
	}
	return 0 ;
}
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

























