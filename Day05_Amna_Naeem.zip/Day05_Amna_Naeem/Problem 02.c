 // A program that checks whether a given number is palindrome or not
 // Palindrome is a number that remains same when its digits are reversed
 #include<stdio.h>
 int main()
 {
 	int num1 , num2 , num3 , num4 ;
 	num2 = 0 ;
 	printf("Enter a number: ");
 	scanf("%d",num1);
 	num4= num1;
 	while(num1!=0)
 	{
 		num3 = num1 % 10 ;
 		num2 = num2*10 + num3 ; // num2 is a reversed number
 		num1 = num1/10 ;
	 }
	 if(num1==num2)
	 {
	 	printf("Palindrome number");
	 }
	 else
	 {
	 	printf("Not Palindrome number");
	 }
	 return 0 ;
 }