// A program that checks whether a given number is a prime number or not
#include<stdio.h>
int main()
{
	int a ;
	printf("Enter a number: ");
	scanf("%d",&a);
	for( int i=2; i<=a/2; i++ )
	{
		 for( int j=2; j<=a/2; j++)
		 {
		 	if(i%j==0)
		 	{
			 
		 		break;
		}
			 if(j>(i/2))
			 {
			 	printf("%d is a prime number\n", i);
			 }
		 }
	}
return 0;	
}