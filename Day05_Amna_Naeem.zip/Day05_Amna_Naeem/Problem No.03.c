// A program to check whether a number that input by a user is armstrong or not
// Armstrong is a number that is equal to the sum of its own digits each raised to the power of the number of the digits
#include<stdio.h>
int main()
{
	int num , remainder , num2 , armstrong ;
	armstrong = 0 ;
	num2 = num ;
	printf("Enter number: ");
	scanf("%d",&num);
	while(num>0)
	{
		remainder = num%10 ;
		armstrong = (remainder*remainder*remainder) + armstrong ;
		num = num/10 ;
	}
	if(num2==armstrong)
	{
		printf("Yes,Armstrong number");
	}
	else
	{
		printf("Not a armstrong number");
	}
	return 0;
}
