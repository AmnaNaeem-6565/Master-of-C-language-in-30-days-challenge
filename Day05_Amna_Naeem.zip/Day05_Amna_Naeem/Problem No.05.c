/* A program that prints that prints the following alphabet triangle 
                                A
                               ABA
                              ABCBA
                             ABCDCBA
*/
#include<stdio.h>
int main()
{
	int range ;
	printf("Enter Range: ");
	scanf("%d",range);
	// Cantrols the number of lines printed on the screen
	for(int i=1; i<=range; i++)
	{
		// cantrols the each character that is printed on the line
		for(int j=1; j<=range-i; j++)
		{
			for(j=1;j<=i;j++)
			{
			printf("%c",'A'+j-1);	
			}
			for(j=i-1;j>=1;j--)
			{
				printf("%c",'A'+j-1);
			}
		}
		printf("\n");
	}
	return 0;
}
                               
                            