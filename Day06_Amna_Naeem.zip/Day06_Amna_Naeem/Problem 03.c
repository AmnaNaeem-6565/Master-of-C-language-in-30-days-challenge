#include<stdio.h>

int main() {
    int T , num , sum;
    sum = 0;
    // T represents the number of test cases the user wants to enter
    scanf("%d",&T);
    for(int i=1; i<=T; i++)
    {
    	// num represents the test case value entered by a user
    	scanf("%d", &num);
    	   for(int j=2; j<num; j++)
    	   {
    	   	prime_num = 1;
    	   	   for(int k=2; k<j; k++)
    	   	   {
    	   	   	if(j%k==0)
					  {
    	   	   		      prime_num=0;
    	   	   		      break;
					  }
				  }
				  if(prime_num)
				  {
				  	sum = sum + j;
				  }
		   }
		   printf("%d\n",sum);
	}
	return 0;
    
}
