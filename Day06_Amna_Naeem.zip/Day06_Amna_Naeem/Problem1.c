// A program that reads the radius of circle from user and displays the area of circle (By user defined function)
#include <stdio.h>
#include <math.h>

 void area(int radius);
 int main()
 {
 	int r ;
 	
 	printf("Enter radius: ");
 	scanf("%d", &r);
 	
 	area(r);
 	
 	return 0;
 	
 }
 void area(int radius)
 {
 	float area;
 	area =(float)(3.14) * pow(radius, 2);
 	printf("Area of Circle: %.1f\n", area);
 	
 }