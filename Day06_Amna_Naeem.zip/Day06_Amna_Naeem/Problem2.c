// Program to find the factors of a number entered by the user

#include <stdio.h>
#include <math.h>

void factorsOfNum(int num);

int main() {
	
	int n;
	
	printf("Enter Number: ");
	scanf("%d", &n);
	
	factorsOfNum(n);
	
	return 0;
}


void factorsOfNum(int num) {
	
		printf("Factors of %d", num);

	for(int i=0; i<= num; i++) {
		
		if (num % i == 0) {
			
			printf("%d ", i);
		}
	}
}
